#' Cleans Data
#'
#' This function takes in a dataframe and returns a dataframe with
#' no missing values. The user can either delete observations
#' with missing values or impute the missing values with the
#' mean/mode of the column.
#'
#' @param df A dataframe that has missing values
#' @param method Specifies which cleaning method to use. "remove"
#' option will delete rows with missing values while "impute" option
#' will replace missing values with the mean if it is a numerical
#' variable or the mode if it is a categorical variable. Note that
#' the missing values in the dataframe must be NA not identified
#' differently.
#' @return A dataframe with no missing values
#'
#' @export

quick_clean <- function(df, method)
{
  if (method == "remove"){
    no_missing <- df[complete.cases(df),]
    return(no_missing)
  }

  else if (method == "impute"){
    replace_mean <- function(df)
    {
      if (is.numeric(df)){
        df[is.na(df)] <- mean(df, na.rm = TRUE)
      }
      return(df)
    }

    most_frequent <- function(x){
      unique_x <- unique(x)
      unique_x[which.max(tabulate(match(x, unique_x)))]
    }

    replace_median <- function(df)
    {
      if (is.factor(df)){
        df[is.na(df)] <- most_frequent(df)
      }
      return(df)
    }

    a <- data.frame(lapply(df, replace_mean))
    b <- data.frame(lapply(a, replace_median))
    return(b)
  }
}

