#' Visual Data
#'
#' This function creates graphs of bar charts, density plots, and
#' scatter plots of all combinations of variables.
#'
#' @param df A dataframe
#' @param task Specifies which visualizations to produce.
    #' 1: Plots all the possible the barcharts of two small categorical variables
    #' 2: Plot all density curves of numeric variables partitioning on each small categorical variable
    #' 3: Plot the scatter plots of  all possible pair of numeric variables
  #' NOTE: Small categorical variables are categorical variables with less than 5 categories
#' @export2

quick_visual <- function(df, task)
{
  library(ggplot2)

  if (is.data.frame(df) & task == 1){
    df_factors <- df[,sapply(df, is.factor)]

    cat.5 <- function(x)
    {
      l <- (length(unique(x)) < 5)
      return(l)
    }

    df_factors5 <- df_factors[,sapply(df_factors, cat.5)]

    combinations <- combn(names(df_factors5), 2, simplify=TRUE)

    bar.charts <- function(d){
      chart <- ggplot(d) +
        geom_bar(mapping = aes(x=d[,1], fill=d[,2]), position = "dodge") +
        xlab(names(d[1])) +
        labs(fill = names(d[2]))

      return(chart)
    }

    c1 <- function(x)
    {
      bar.charts(df_factors5[,x])
    }

    charts <- apply(combinations, 2, c1)

    return(charts)

  }else if (is.data.frame(df) & task == 2){
    for (i in 1:ncol(df)){
      if (is.numeric(df[,i])){
        for (j in i:ncol(df)){
          if (is.factor(df[,j]) & (length(unique(df[,j]) < 5))){
            print(ggplot(df) +
              geom_density(mapping = aes(x = df[,i], fill = df[,j])) +
              xlab(names(df)[i]) +
              labs(fill = names(df)[j]))
          }
        }
      }
    }

  }else if (is.data.frame(df) & task == 3){
    df_numeric <- df[,sapply(df, is.numeric)]

    combinations <- combn(names(df_numeric), 2, simplify=TRUE)

    scatter <- function(d){
      chart <- ggplot(d) +
        geom_point(mapping = aes(x=d[,1], y=d[,2])) +
        xlab(names(d[1])) +
        ylab(names(d[2]))

      return(chart)
    }

    c1 <- function(x)
    {
      scatter(df_numeric[,x])
    }

    scatters <- apply(combinations, 2, c1)

    return(scatters)

  }else
    print("ERROR: Input(s) not valid")
}
