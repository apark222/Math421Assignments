#' Train a Random Forest Model
#'
#' Takes in a dataframe and target variable and trains a random forest model. The process uses a 70/30 split between training and testing data respectively and uses the default settings of the 'ranger' package to build the model. The accuracy and confusion matrix of the model are then reported.
#'
#' @param df A dataframe that has no missing values. If there are missing observations the function will not run.
#' @param target The target variable of the dataframe. This must be specified in quotes ("target").
#'
#' @return A confusion matrix of the default model built by the 'ranger' package.
#'
#' @export

quick_model <- function(df, target)
{
  if (is.data.frame(df) & (target %in% colnames(df))){
    if (sum(is.na(df)) == 0){

      library(caret)
      library(ranger)

      colnames(df)[colnames(df) == target] <- "target"

      split <- createDataPartition(df$target, p = .7, list = FALSE, times = 1)
      df_train <- df[split,]
      df_test <- df[-split,]

      random_forest <- ranger(target ~ ., data = df_train)
      rf_predict <- predict(random_forest, data = df_test)$predictions
      rf_cm <- confusionMatrix(data = rf_predict, df_test$target)

      return(rf_cm)

      }else
        print("ERROR: Dataframe has missing values")
  } else
    print("ERROR: Inputs are invalid")
}
